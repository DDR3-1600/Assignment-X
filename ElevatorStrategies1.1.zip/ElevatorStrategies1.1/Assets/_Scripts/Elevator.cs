﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public enum ElevatorState { PARKED, MOVING, DOCKING, WAITING, TERMINAL, SEEKING, STUB_STATE };
public enum ElevatorDirection { NEUTRAL, UP, DOWN };

public class Elevator : MonoBehaviour {
    public int elevatorNumber;
    public HashSet<int> upFloorRequests;
    public HashSet<int> downFloorRequests;
    public float speed;
    public ElevatorState _elevatorState;
    public ElevatorState elevatorState
    {
        get
        {
            lock(_locker)
            {
                return _elevatorState;
            }
        }
        set
        {
            lock(_locker)
            {
                _elevatorState = value;
                print("*" + elevatorNumber + " " + _elevatorState);
            }
        }
    }
    public ElevatorDirection elevatorDirection;
    public Floor currentFloor;
    public bool selected;
    public Material selectedElevator, nonSelectedElevator;
    public float smoothTime = 0.3F;
    private float yVelocity = 0.0F;
    private readonly object _locker = new object();
    public int seekingFloor;
    public ElevatorDirection directionToService;

    // Use this for initialization
    void Awake () {
        elevatorNumber = Int32.Parse(gameObject.name.Substring(10, 1));
        upFloorRequests = new HashSet<int>();
        downFloorRequests = new HashSet<int>();
        elevatorState = ElevatorState.TERMINAL;
        elevatorDirection = ElevatorDirection.NEUTRAL;
	}
	
	// Update is called once per frame
	void Update () {
        switch (elevatorState)
        {
            case ElevatorState.PARKED:
                switch (elevatorDirection)
                {
                    case ElevatorDirection.NEUTRAL:
                        if(upFloorRequests.Count > 0 && downFloorRequests.Count > 0)
                        {
                            int lowestFloor = Lowest(upFloorRequests);
                            int highestFloor = Highest(downFloorRequests);
                            if(Mathf.Abs(currentFloor.floorNumber - lowestFloor) < Mathf.Abs(currentFloor.floorNumber - highestFloor))
                            {
                                seekingFloor = Lowest(upFloorRequests);
                                if(seekingFloor > currentFloor.floorNumber)
                                {
                                    elevatorDirection = ElevatorDirection.UP;
                                }
                                else
                                {
                                    elevatorDirection = ElevatorDirection.DOWN;
                                }
                                elevatorState = ElevatorState.SEEKING;
                                directionToService = ElevatorDirection.UP;
                            }
                            else
                            {
                                seekingFloor = Highest(downFloorRequests);
                                if (seekingFloor > currentFloor.floorNumber)
                                {
                                    elevatorDirection = ElevatorDirection.UP;
                                }
                                else
                                {
                                    elevatorDirection = ElevatorDirection.DOWN;
                                }
                                elevatorState = ElevatorState.SEEKING;
                                directionToService = ElevatorDirection.DOWN;
                            }
                        }
                        else
                        {
                            if (upFloorRequests.Count > 0)
                            {
                                seekingFloor = Lowest(upFloorRequests);
                                if (seekingFloor > currentFloor.floorNumber)
                                {
                                    elevatorDirection = ElevatorDirection.UP;
                                }
                                else
                                {
                                    elevatorDirection = ElevatorDirection.DOWN;
                                }
                                elevatorState = ElevatorState.SEEKING;
                                directionToService = ElevatorDirection.UP;
                            }
                            if (downFloorRequests.Count > 0)
                            {
                                seekingFloor = Highest(downFloorRequests);
                                if (seekingFloor > currentFloor.floorNumber)
                                {
                                    elevatorDirection = ElevatorDirection.UP;
                                }
                                else
                                {
                                    elevatorDirection = ElevatorDirection.DOWN;
                                }
                                elevatorState = ElevatorState.SEEKING;
                                directionToService = ElevatorDirection.DOWN;
                            }
                        }
                        break;
                    case ElevatorDirection.UP:
                        if(currentFloor.terminal)
                        {
                            elevatorState = ElevatorState.TERMINAL;
                            upFloorRequests.Remove(currentFloor.floorNumber);
                        }
                        else
                        {
                            if (upFloorRequests.Count > 0)
                            {
                                if (!upFloorRequests.Contains(currentFloor.floorNumber))
                                {
                                    elevatorState = ElevatorState.MOVING;
                                }
                                else
                                {
                                    upFloorRequests.Remove(currentFloor.floorNumber);
                                }
                            }
                            else
                            {
                                if (downFloorRequests.Count > 0)
                                {
                                    elevatorDirection = ElevatorDirection.DOWN;
                                    elevatorState = ElevatorState.MOVING;
                                }
                                else
                                {
                                    elevatorDirection = ElevatorDirection.NEUTRAL;
                                    //elevatorState = ElevatorState.TERMINAL;
                                }
                            }
                        }
                        break;
                    case ElevatorDirection.DOWN:
                        if(currentFloor.terminal)
                        {
                            elevatorState = ElevatorState.TERMINAL;
                            downFloorRequests.Remove(currentFloor.floorNumber);
                        }
                        else
                        {
                            if (downFloorRequests.Count > 0)
                            {
                                if (!downFloorRequests.Contains(currentFloor.floorNumber))
                                {
                                    elevatorState = ElevatorState.MOVING;
                                }
                                else
                                {
                                    downFloorRequests.Remove(currentFloor.floorNumber);
                                }
                            }
                            else
                            {
                                if (upFloorRequests.Count > 0)
                                {
                                    elevatorDirection = ElevatorDirection.UP;
                                    elevatorState = ElevatorState.MOVING;
                                }
                                else
                                {
                                    elevatorDirection = ElevatorDirection.NEUTRAL;
                                    //elevatorState = ElevatorState.TERMINAL;
                                }
                            }
                        }
                        break;
                }
                break;
            case ElevatorState.MOVING:
                switch (elevatorDirection)
                {
                    case ElevatorDirection.NEUTRAL:
                        break;
                    case ElevatorDirection.UP:
                        transform.Translate(Vector3.up * Time.deltaTime * speed);
                        break;
                    case ElevatorDirection.DOWN:
                        transform.Translate(Vector3.down * Time.deltaTime * speed);
                        break;
                }
                break;
            case ElevatorState.DOCKING:
                float newHeight = Mathf.SmoothDamp(transform.position.y, currentFloor.transform.position.y, ref yVelocity, smoothTime);
                transform.position = new Vector3(transform.position.x, newHeight, transform.position.z);
                break;
            case ElevatorState.TERMINAL:
                switch(elevatorDirection)
                {
                    case ElevatorDirection.NEUTRAL:
                        if(currentFloor.floorNumber > 1)
                        {
                            if(downFloorRequests.Count > 0)
                            {
                                seekingFloor = Highest(downFloorRequests);
                                elevatorDirection = ElevatorDirection.DOWN;
                                elevatorState = ElevatorState.MOVING;
                                directionToService = ElevatorDirection.DOWN;
                            }
                            else
                            {
                                if(upFloorRequests.Count > 0)
                                {
                                    seekingFloor = Lowest(upFloorRequests);
                                    elevatorDirection = ElevatorDirection.DOWN;
                                    elevatorState = ElevatorState.SEEKING;
                                    directionToService = ElevatorDirection.UP;
                                }
                            }
                        }
                        else
                        {
                            if (upFloorRequests.Count > 0)
                            {
                                seekingFloor = Lowest(upFloorRequests);
                                elevatorDirection = ElevatorDirection.UP;
                                elevatorState = ElevatorState.MOVING;
                                directionToService = ElevatorDirection.UP;
                            }
                            else
                            {
                                if (downFloorRequests.Count > 0)
                                {
                                    seekingFloor = Highest(downFloorRequests);
                                    elevatorDirection = ElevatorDirection.UP;
                                    elevatorState = ElevatorState.SEEKING;
                                    directionToService = ElevatorDirection.DOWN;
                                }
                            }
                        }
                        break;
                    case ElevatorDirection.UP:
                        if (downFloorRequests.Count > 0)
                        {
                            elevatorDirection = ElevatorDirection.DOWN;
                            elevatorState = ElevatorState.MOVING;
                        }
                        else
                        {
                            elevatorDirection = ElevatorDirection.NEUTRAL;
                            //elevatorState = ElevatorState.TERMINAL;
                        }
                        break;
                    case ElevatorDirection.DOWN:
                        if (upFloorRequests.Count > 0)
                        {
                            elevatorDirection = ElevatorDirection.UP;
                            elevatorState = ElevatorState.MOVING;
                        }
                        else
                        {
                            elevatorDirection = ElevatorDirection.NEUTRAL;
                            //elevatorState = ElevatorState.TERMINAL;
                        }
                        break;
                }
                break;
            case ElevatorState.WAITING:
                elevatorState = ElevatorState.STUB_STATE;
                StartCoroutine(WaitToPark());
                break;
            case ElevatorState.SEEKING:
                switch (elevatorDirection)
                {
                    case ElevatorDirection.NEUTRAL:
                        break;
                    case ElevatorDirection.UP:
                        transform.Translate(Vector3.up * Time.deltaTime * speed);
                        break;
                    case ElevatorDirection.DOWN:
                        transform.Translate(Vector3.down * Time.deltaTime * speed);
                        break;
                }
                break;
            case ElevatorState.STUB_STATE:
                break;
        }
    }

    private IEnumerator WaitToPark()
    {
        yield return new WaitForSeconds(1f);
        elevatorState = ElevatorState.PARKED;
    }

    private IEnumerator DockToWait()
    {
        yield return new WaitForSeconds(1f);
        elevatorState = ElevatorState.WAITING;
    }

    private int Highest(HashSet<int> set)
    {
        int highest = 1;
        if(set.Count > 0)
        {
            foreach(int floor in set)
            {
                if(floor > highest)
                {
                    highest = floor;
                }
            }
        }

        return highest;
    }

    private int Lowest(HashSet<int> set)
    {
        int lowest = 19;
        if(set.Count > 0)
        {
            foreach(int floor in set)
            {
                if(floor < lowest)
                {
                    lowest = floor;
                }
            }
        }

        return lowest;
    }

    public void elevatorRequest(int floorNumber)
    {
        if(floorNumber != currentFloor.floorNumber)
        {
            if (floorNumber > currentFloor.floorNumber)
            {
                if(elevatorDirection == ElevatorDirection.NEUTRAL)
                {
                    elevatorState = ElevatorState.SEEKING;
                    elevatorDirection = ElevatorDirection.UP;
                    seekingFloor = floorNumber;
                }
                else
                {
                    elevatorRequest(floorNumber, ElevatorDirection.UP);
                }
            }
            else
            {
                if(elevatorDirection == ElevatorDirection.NEUTRAL)
                {
                    elevatorState = ElevatorState.SEEKING;
                    elevatorDirection = ElevatorDirection.DOWN;
                    seekingFloor = floorNumber;
                }
                else
                {
                    elevatorRequest(floorNumber, ElevatorDirection.DOWN);
                }
            }
        }
    }

    public void elevatorRequest(int floorNumber, ElevatorDirection direction)
    {
        if(floorNumber != currentFloor.floorNumber)
        {
            switch (direction)
            {
                case ElevatorDirection.NEUTRAL:
                    break;
                case ElevatorDirection.UP:
                    upFloorRequests.Add(floorNumber);
                    break;
                case ElevatorDirection.DOWN:
                    downFloorRequests.Add(floorNumber);
                    break;
            }
            if(elevatorDirection == ElevatorDirection.NEUTRAL)
            {

            }
        }
    }

    void OnTriggerEnter(Collider other)
    {
        Floor floor = other.gameObject.GetComponent<Floor>();
        if (floor != null)
        {
            currentFloor = floor;
            print("Elevator " + elevatorNumber + " entering floor " + currentFloor.floorNumber);
            switch(elevatorState)
            {
                case ElevatorState.MOVING:
                    switch (elevatorDirection)
                    {
                        case ElevatorDirection.NEUTRAL:
                            break;
                        case ElevatorDirection.UP:
                            if (floor.terminal)
                            {
                                //elevatorDirection = ElevatorDirection.DOWN;
                                elevatorState = ElevatorState.DOCKING;
                                StartCoroutine(DockToWait());
                            }
                            else
                            {
                                if (upFloorRequests.Count > 0)
                                {
                                    if (upFloorRequests.Contains(floor.floorNumber))
                                    {
                                        elevatorState = ElevatorState.DOCKING;
                                        currentFloor.up = false;
                                        StartCoroutine(DockToWait());
                                        //upFloorRequests.Remove(floor.floorNumber);
                                    }
                                }
                            }
                            break;
                        case ElevatorDirection.DOWN:
                            if (floor.terminal)
                            {
                                //elevatorDirection = ElevatorDirection.UP;
                                elevatorState = ElevatorState.DOCKING;
                                StartCoroutine(DockToWait());
                            }
                            else
                            {
                                if (downFloorRequests.Count > 0)
                                {
                                    if (downFloorRequests.Contains(floor.floorNumber))
                                    {
                                        elevatorState = ElevatorState.DOCKING;
                                        currentFloor.down = false;
                                        StartCoroutine(DockToWait());
                                        //downFloorRequests.Remove(floor.floorNumber);
                                    }
                                }
                            }
                            break;
                    }
                    break;
                case ElevatorState.SEEKING:
                    if(seekingFloor == currentFloor.floorNumber)
                    {
                        elevatorDirection = directionToService;
                        elevatorState = ElevatorState.DOCKING;
                        StartCoroutine(DockToWait());
                    }
                    break;
            }
        }
    }

    public void select(bool selected)
    {
        if(selected)
        {
            gameObject.GetComponent<Renderer>().material = selectedElevator;
        }
        else
        {
            gameObject.GetComponent<Renderer>().material = nonSelectedElevator;
        }
    }
}
