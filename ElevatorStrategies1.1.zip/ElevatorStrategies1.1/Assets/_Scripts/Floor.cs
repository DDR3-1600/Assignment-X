﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class Floor : MonoBehaviour {
    public int floorNumber;
    public bool terminal;
    public bool up;
    public bool down;
    public bool selected;
    public Material selectedFloor, nonSelectedFloor;

	// Use this for initialization
	void Awake () {
        string temp = gameObject.name.Substring(7, 2);
        if(temp.Contains(")"))
        {
            temp = temp.Substring(0, 1);
        }
        floorNumber = Int32.Parse(temp);
        up = false;
        down = false;
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    public void requestElevator(ElevatorDirection direction)
    {
        switch(direction)
        {
            case ElevatorDirection.UP:
                up = true;
                break;
            case ElevatorDirection.DOWN:
                down = true;
                break;
        }
    }

    public void select(bool selected)
    {
        if(selected)
        {
            gameObject.GetComponent<Renderer>().material = selectedFloor;
        }
        else
        {
            gameObject.GetComponent<Renderer>().material = nonSelectedFloor;
        }
    }
}
