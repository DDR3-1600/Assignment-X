﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SingleElevatorStrategy : StrategyInterface {
    private BuildingController _buildingController;
    private Elevator selectedElevator;
    private string _name;
    public string name
    {
        get
        {
            return _name;
        }
    }

    public SingleElevatorStrategy()
    {
        _name = "Single Elevator Strategy";
    }

    public BuildingController buildingController { set { _buildingController = value; } }

    public void requestElevator(int floorNumber, ElevatorDirection direction)
    {

        if(_buildingController != null && selectedElevator != null)
        {
            if (selectedElevator != null)
            {
                selectedElevator.elevatorRequest(floorNumber, direction);
            }
            else
            {
                Debug.Log("The selected elevator has not been initialized.");
            }
        }
        else
        {
            Debug.Log("The building controller has not been initialized.");
        }
    }

    public void selectElevator(int elevatorNumber)
    {
        if(_buildingController != null)
        {
            selectedElevator = _buildingController.elevators[elevatorNumber];
        }
    }

}
