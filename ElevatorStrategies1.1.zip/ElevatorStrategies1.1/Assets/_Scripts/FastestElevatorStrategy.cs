﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
// Jacob Robertson
//4/23/2018
//fast elevator stradgy
public class FastestElevatorStrategy : StrategyInterface
{
    private BuildingController _buildingController;
    private Elevator selectedElevator;
    private string _name;
    public string name
    {
        get
        {
            return _name;
        }
    }

    public FastestElevatorStrategy()
    {
        _name = "FastestElevatorStrategy";
    }

    public BuildingController buildingController { set { _buildingController = value; } }

    public void requestElevator(int floorNumber, ElevatorDirection direction)
    {
        //*******************************************************************

 
        int topFloor = 19;
        int dist = 99;
        int target = floorNumber;
        int worker = 0;
        // logic is to fan elevators so that they are spaced evenly to make for a faster call time
        int spacing = 5;
        if (_buildingController != null && selectedElevator != null)
        {
            if (selectedElevator != null)
            {
                foreach (var ind in _buildingController.elevators)
                {

                    // below code spaces out elevators
                    ind.Value.elevatorRequest(topFloor);
                    if (topFloor < 5)
                    {
                        topFloor = 1;
                    }
                    else
                    {
                        topFloor = topFloor - spacing;
                    }
                    // below code attempts to patch the tragic event of an elevator falling into the earth
                    if (ind.Value.currentFloor.floorNumber == -1)
                    {
                        ind.Value.elevatorRequest(1);
                    }
                    worker = Mathf.Abs(ind.Value.currentFloor.floorNumber - target);
                  
                    if (dist > worker)
                    {
                        dist = worker;
                        selectedElevator = ind.Value;

                    }
                    // below code removes downward elevator requests below 1 ( i dont think this does anything )
                    if (ind.Value.downFloorRequests != null)
                    {
                        foreach (var helpmejesus in ind.Value.downFloorRequests)
                        {
                            if (helpmejesus < 1)
                            {
                                ind.Value.downFloorRequests.Remove(helpmejesus);
                            }
                        }

                    }
                    
                }
                
                selectedElevator.elevatorRequest(floorNumber, direction);


            }

        }
    }
    public void selectElevator(int elevatorNumber)
    {
        if (_buildingController != null)
        {
            selectedElevator = _buildingController.elevators[elevatorNumber];
        }
    }

}

