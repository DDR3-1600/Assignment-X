﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;


public interface StrategyInterface {
    BuildingController buildingController { set; }
    void requestElevator(int floorNumber, ElevatorDirection direction);
    string name { get; }
}
