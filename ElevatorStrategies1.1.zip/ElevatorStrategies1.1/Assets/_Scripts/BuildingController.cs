﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using UnityEngine.UI;

public class BuildingController : MonoBehaviour {
    public Dropdown floorSelector;
    public Dropdown elevatorSelector;
    public Dictionary<int, Floor> floors;
    public Dictionary<int, Elevator> elevators;
    public Floor currentFloor;
    public Elevator currentElevator;
    public StrategyInterface strategy;
    public Text strategyLabel;

    // Use this for initialization
    void Start () {
        GameObject[] floorReferences = GameObject.FindGameObjectsWithTag("Floor");
        List<string> floorOptions = new List<string>();
        floors = new Dictionary<int, Floor>();
        int floorNumber = 1;
        foreach(GameObject go in floorReferences)
        {
            Floor floor = go.GetComponent<Floor>();
            floors[floor.floorNumber] = floor;
            floorOptions.Add(floorNumber.ToString());
            floorNumber++;
        }
        floorSelector.ClearOptions();
        floorSelector.AddOptions(floorOptions);
        selectFloor(0);

        GameObject[] elevatorReferences = GameObject.FindGameObjectsWithTag("Elevator");
        List<string> elevatorOptions = new List<string>();
        elevators = new Dictionary<int, Elevator>();
        int elevatorNumber = 1;
        foreach(GameObject go in elevatorReferences)
        {
            Elevator elevator = go.GetComponent<Elevator>();
            elevators[elevator.elevatorNumber] = elevator;
            elevatorOptions.Add(elevatorNumber.ToString());
            elevatorNumber++;
        }
        elevatorSelector.ClearOptions();
        elevatorSelector.AddOptions(elevatorOptions);
        selectElevator(0);
        // Setup strategy to use
        //SingleElevatorStrategy sis = new SingleElevatorStrategy();

        //fast strat by Jacob.
        // at most elevators are 3 away
        // call, then same call will refan
        // ONLY USE UP ELEVATOR CALL BUTTON 
        FastestElevatorStrategy sis = new FastestElevatorStrategy();

        sis.buildingController = this;
        sis.selectElevator(5);
        strategy = sis;
        strategyLabel.text = sis.name;
	}
	
	// Update is called once per frame
	void Update () {

    }

    public void requestFloor(int floorNumber)
    {
        currentElevator.elevatorRequest(floorNumber);
    }

    public void requestElevator(int direction)
    {
        switch(direction)
        {
            case 0:
                requestElevator(currentFloor.floorNumber, ElevatorDirection.UP);
                break;
            case 1:
                requestElevator(currentFloor.floorNumber, ElevatorDirection.DOWN);
                break;
            default:
                break;
        }
        
    }
    
    public void requestElevator(int floorNumber, ElevatorDirection direction)
    {
        if(strategy != null)
        {
            strategy.requestElevator(floorNumber, direction);
        }
    }

    public void requestElevator(int elevatorNumber, int floorNumber, ElevatorDirection direction)
    {
        Elevator elevator = elevators[elevatorNumber];
        if(elevator != null)
        {
            elevator.elevatorRequest(floorNumber, direction);
        }
        else
        {
            Debug.Log("RequestElevator: Invalid Elevator Number " + elevatorNumber);
        }
    }

    public void selectFloor(int index)
    {
        currentFloor.gameObject.GetComponent<Floor>().select(false);
        currentFloor = floors[Int32.Parse(floorSelector.captionText.text)];
        currentFloor.gameObject.GetComponent<Floor>().select(true);
    }

    public void selectElevator(int index)
    {
        currentElevator.gameObject.GetComponent<Elevator>().select(false);
        currentElevator = elevators[Int32.Parse(elevatorSelector.captionText.text)];
        currentElevator.gameObject.GetComponent<Elevator>().select(true);
    }
}
